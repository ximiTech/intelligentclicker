#!/bin/sh

# This script is called by /etc/init.d/openclash



exit 0